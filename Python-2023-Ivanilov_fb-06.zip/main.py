import sys
import time
import math


def factors_module(n, b, y, p, h):
    r = {pow(b, (n - 1) // p * jj, n): jj for jj in range(p)}

    def calculate_x_y(ix, x, y):
        if ix == h:
            return x % pow(p, h)

        temp = pow(y, (n - 1) // pow(p, ix + 1), n)
        x = x + (pow(p, ix) * r[temp])
        temp = pow(b, pow(p, ix) * (-r[temp] + (n - 1 if r[temp] < 0 else 0)), n)
        y *= temp % n

        return calculate_x_y(ix + 1, x, y)

    return calculate_x_y(0, 0, y)


def extended_euclid(a, b):
    x, y = 0, 1
    last_x, last_y = 1, 0
    while b != 0:
        quotient = a // b
        a, b = b, a % b
        x, last_x = last_x - quotient * x, x
        y, last_y = last_y - quotient * y, y
    return a, last_x, last_y


def factorize(n):
    def factorize_recursive(n, i, factors):
        if n == 1:
            return factors
        while n % i != 0:
            i += 1
        factors[i] = factors.get(i, 0) + 1
        return factorize_recursive(n // i, i, factors)

    return factorize_recursive(n, 2, {})


def silver_pohlig_hellman(a, b, m):
    factors = factorize(m - 1)
    x = [factors_module(m, a, b, p, e) for p, e in factors.items()]
    M = math.prod([pow(p, e) for p, e in factors.items()])
    result = sum(x[i] * M // pow(p, e) * extended_euclid(M // pow(p, e), pow(p, e))[1] for i, (p, e) in
                 enumerate(factors.items()))
    result = result % (m - 1) if result > m - 1 else (result + m - 1) % (m - 1)
    return result


def discrete_log(g, h, p):
    start_time = time.time()
    limit = 60 * 5

    for x in range(p):
        if g ** x % p == h and time.time() - start_time < limit:
            print(time.time() - start_time)
            return x

        if time.time() - start_time > limit:
            print(time.time() - start_time)
            return "Час вичерпано"
    return "Розв'язок не знайдено"

# print()
# print("input a:")
# a = int(input())
#
# print("input b:")
# b = int(input())
#
# print("input p:")
# p = int(input())

tasks1 = [[305, 110, 599], [304, 201, 401], [2513, 870, 4759], [35768, 34528, 56501], [320774, 430278, 488639], [190177, 261140, 665359], [1557464, 5009176, 12369059], [167357551, 302646126, 433096217]]
tasks2 = [[2, 95, 101], [15, 127, 227], [14, 4171, 9187], [5793, 27172, 30467], [837565, 138096, 966883], [2785064, 190127, 7513529], [24960337, 25504616, 27535987], [65940087, 93027348, 158519479]]


# # Now call the silver_pohlig_hellman function with these inputs
# start_time = time.time()
# result = silver_pohlig_hellman(a, b, p)
# end_time = time.time()
#
# print("x =", result)
# print("Runtime:", end_time - start_time, "seconds")
import matplotlib.pyplot as plt

i = 2
sph_times1, dl_times1, sph_times2, dl_times2 = [], [], [], []
sizes = []

for task1, task2 in zip(tasks1, tasks2):
    sizes.append(i)
    if len(task1) == 3:
        a, b, p = task1
        start_time1 = time.time()
        result1 = silver_pohlig_hellman(a, b, p)
        end_time1 = time.time() - start_time1
        sph_times1.append(end_time1)

        start_time2 = time.time()
        result2 = discrete_log(a, b, p)
        end_time2 = time.time() - start_time2
        dl_times1.append(end_time2)

    if len(task2) == 3:
        a, b, p = task2
        start_time1 = time.time()
        result1 = silver_pohlig_hellman(a, b, p)
        end_time1 = time.time() - start_time1
        sph_times2.append(end_time1)

        start_time2 = time.time()
        result2 = discrete_log(a, b, p)
        end_time2 = time.time() - start_time2
        dl_times2.append(end_time2)

    i += 1

# Compare times between methods for each task
for i in range(len(sizes)):
    print(f"For task size {sizes[i]}: ")
    print(f"  Time difference between silver_pohlig_hellman and discrete_log for task1: {abs(sph_times1[i] - dl_times1[i])} seconds")
    print(f"  Time difference between silver_pohlig_hellman and discrete_log for task2: {abs(sph_times2[i] - dl_times2[i])} seconds")

# Create visualization of runtime dependence on input parameter
plt.figure(figsize=(10, 6))

plt.plot(sizes, sph_times1, marker='o', label='silver_pohlig_hellman Task1')
plt.plot(sizes, dl_times1, marker='o', label='discrete_log Task1')
plt.plot(sizes, sph_times2, marker='o', label='silver_pohlig_hellman Task2')
plt.plot(sizes, dl_times2, marker='o', label='discrete_log Task2')

plt.xlabel('Input Parameter')
plt.ylabel('Time (seconds)')
plt.legend()
plt.title('Time Complexity')
plt.show()